import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Navbar, Nav, Container, Button, NavDropdown } from "react-bootstrap";

function NavigationBar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  const handleLogout = () => {
    localStorage.clear(); // clear all auth data
    navigate("/login");
  };

  return (
    <Navbar bg="dark" expand="lg" variant="dark">
      <Container>
        <Navbar.Brand as={Link} to="/">🏥 HealthCare</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {!token ? (
              <>
                <Nav.Link as={Link} to="/login">Login</Nav.Link>

                {/* Dropdown for Register */}
                <NavDropdown title="Register" id="register-dropdown">
                  <NavDropdown.Item as={Link} to="/register">Patient</NavDropdown.Item>
                  <NavDropdown.Item as={Link} to="/register/provider">Provider</NavDropdown.Item>
                </NavDropdown>
              </>
            ) : (
              <>
                {/* Show dashboard link based on role */}
                {role === "PATIENT" && (
                  <Nav.Link as={Link} to="/patient">Dashboard</Nav.Link>
                )}
                {(role === "DOCTOR" || role === "WELLNESS_PROVIDER") && (
                  <Nav.Link as={Link} to="/provider">Dashboard</Nav.Link>
                )}
                {role === "ADMIN" && (
                  <Nav.Link as={Link} to="/admin">Admin</Nav.Link>
                )}

                <Button
                  variant="danger"
                  className="ms-3"
                  onClick={handleLogout}
                >
                  Logout
                </Button>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavigationBar;
