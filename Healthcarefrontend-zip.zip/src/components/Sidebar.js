import React from "react";
import { ListGroup } from "react-bootstrap";
import { Link } from "react-router-dom";

function Sidebar({ links }) {
  return (
    <div className="bg-light p-3 shadow" style={{ height: "100vh", minWidth: "220px" }}>
      <h5 className="mb-4">📋 Menu</h5>
      <ListGroup variant="flush">
        {links.map((link, i) => (
          <ListGroup.Item key={i} action as={Link} to={link.path}>
            {link.label}
          </ListGroup.Item>
        ))}
      </ListGroup>
    </div>
  );
}
export default Sidebar;
