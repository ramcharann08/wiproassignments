import React, { useState } from "react";
import API from "../api/axiosConfig";
import { Card, Form, Button, Container, Row, Col } from "react-bootstrap";

function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    age: "",
    gender: "",
    role: "PATIENT", // ✅ default role
  });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let endpoint = "/auth/register/patient";

      if (form.role === "ADMIN") {
        endpoint = "/auth/register/admin";
      } else if (form.role === "PATIENT") {
        endpoint = "/auth/register/patient";
      }

      await API.post(endpoint, form);
      alert(`${form.role} registration successful! Please login.`);
    } catch (err) {
      console.error("Registration error:", err);
      alert("Registration failed!");
    }
  };

  return (
    <Container
      className="d-flex justify-content-center align-items-center"
      style={{ minHeight: "80vh" }}
    >
      <Row>
        <Col>
          <Card style={{ width: "30rem" }} className="shadow">
            <Card.Body>
              <h3 className="text-center mb-4">📝 Register</h3>
              <Form onSubmit={handleSubmit}>
                {/* Role Selection */}
                <Form.Group className="mb-3">
                  <Form.Label>Register As</Form.Label>
                  <Form.Select
                    name="role"
                    value={form.role}
                    onChange={handleChange}
                  >
                    <option value="PATIENT">Patient</option>
                    <option value="ADMIN">Admin</option>
                  </Form.Select>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    placeholder="Full name"
                    value={form.name}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={form.email}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={form.password}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                {/* ✅ Only show Patient details if role is PATIENT */}
                {form.role === "PATIENT" && (
                  <>
                    <Form.Group className="mb-3">
                      <Form.Label>Phone</Form.Label>
                      <Form.Control
                        type="text"
                        name="phone"
                        placeholder="Phone number"
                        value={form.phone}
                        onChange={handleChange}
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Age</Form.Label>
                      <Form.Control
                        type="number"
                        name="age"
                        placeholder="Age"
                        value={form.age}
                        onChange={handleChange}
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Gender</Form.Label>
                      <Form.Select
                        name="gender"
                        value={form.gender}
                        onChange={handleChange}
                      >
                        <option value="">Select Gender</option>
                        <option value="MALE">Male</option>
                        <option value="FEMALE">Female</option>
                        <option value="OTHER">Other</option>
                      </Form.Select>
                    </Form.Group>
                  </>
                )}

                <Button type="submit" className="w-100" variant="success">
                  Register
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Register;
