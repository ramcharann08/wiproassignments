import React from "react";
import { Container, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="bg-light text-center" style={{ minHeight: "90vh", paddingTop: "80px" }}>
      <Container>
        <h1 className="mb-4">🏥 Welcome to HealthCare & Wellness Portal</h1>
        <p className="lead">Book appointments, access wellness services, and manage your health easily.</p>
        <Link to="/register">
          <Button variant="primary" size="lg" className="m-2">Get Started</Button>
        </Link>
        <Link to="/login">
          <Button variant="outline-dark" size="lg" className="m-2">Login</Button>
        </Link>
      </Container>
    </div>
  );
}
export default Home;
