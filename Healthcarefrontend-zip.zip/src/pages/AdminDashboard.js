import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { Row, Col, Card, Table, Button, Modal, Form, Spinner } from "react-bootstrap";
import API from "../api/axiosConfig";

function AdminDashboard() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);

  // ✅ Admin summary counts
  const [providerCount, setProviderCount] = useState(0);
  const [patientCount, setPatientCount] = useState(0);
  const [totalEnrollments, setTotalEnrollments] = useState(0);
  const [enrollmentCounts, setEnrollmentCounts] = useState({});

  const [form, setForm] = useState({
    name: "",
    description: "",
    duration: "",
    fee: ""
  });

  // ✅ Fetch wellness services
  const fetchServices = () => {
    setLoading(true);
    API.get("/admin/wellness")
      .then((res) => setServices(res.data))
      .catch(() => alert("Error fetching wellness services"))
      .finally(() => setLoading(false));
  };

  // ✅ Fetch summary stats
  const fetchCounts = async () => {
    try {
      const [providers, patients, totalEnr, enrByProgram] = await Promise.all([
        API.get("/admin/providers/count"),
        API.get("/admin/patients/count"),
        API.get("/admin/enrollments/count"),
        API.get("/admin/wellness/enrollments/count")
      ]);
      setProviderCount(providers.data);
      setPatientCount(patients.data);
      setTotalEnrollments(totalEnr.data);
      setEnrollmentCounts(enrByProgram.data);
    } catch (err) {
      console.error("Error fetching counts:", err);
    }
  };

  useEffect(() => {
    fetchServices();
    fetchCounts();
  }, []);

  // ✅ Open modal for Add or Edit
  const handleShow = (service = null) => {
    if (service) {
      setEditId(service.id);
      setForm({
        name: service.name,
        description: service.description,
        duration: service.duration,
        fee: service.fee
      });
    } else {
      setEditId(null);
      setForm({ name: "", description: "", duration: "", fee: "" });
    }
    setShowModal(true);
  };

  const handleClose = () => setShowModal(false);

  // ✅ Save new or updated service
  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await API.put(`/admin/wellness/${editId}`, form);
        alert("Service updated successfully!");
      } else {
        await API.post("/admin/wellness", form);
        alert("Service created successfully!");
      }
      handleClose();
      fetchServices();
      fetchCounts();
    } catch (err) {
      console.error("Error saving wellness service:", err);
      alert("Error saving wellness service");
    }
  };

  // ✅ Delete service
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this service?")) return;
    try {
      await API.delete(`/admin/wellness/${id}`);
      alert("Service deleted successfully!");
      fetchServices();
      fetchCounts();
    } catch (err) {
      console.error("Error deleting service:", err);
      alert("Error deleting service");
    }
  };

  return (
    <Row>
      {/* Sidebar */}
      <Col md={3}>
        <Sidebar
          links={[
            { label: "Dashboard", path: "/admin" },
            { label: "Doctors", path: "/doctors" },
            { label: "Patients", path: "/patients" },
            { label: "Services", path: "/services" }
          ]}
        />
      </Col>

      {/* Main Content */}
      <Col md={9} className="p-4">
        <h2>🛠 Admin Dashboard</h2>

        {/* ✅ Summary Cards */}
        <Row className="mb-4">
          <Col md={3}>
            <Card className="shadow text-center p-3 bg-light">
              <h5>👨‍⚕️ Providers</h5>
              <h3>{providerCount}</h3>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="shadow text-center p-3 bg-light">
              <h5>🧑‍🤝‍🧑 Patients</h5>
              <h3>{patientCount}</h3>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="shadow text-center p-3 bg-light">
              <h5>📊 Total Enrollments</h5>
              <h3>{totalEnrollments}</h3>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="shadow text-center p-3 bg-light">
              <h5>💆 Per Program</h5>
              <ul className="list-unstyled small mb-0">
                {Object.entries(enrollmentCounts).map(([program, count]) => (
                  <li key={program}>
                    {program}: <strong>{count}</strong>
                  </li>
                ))}
              </ul>
            </Card>
          </Col>
        </Row>

        {/* ✅ Wellness Program Management */}
        <Card className="shadow p-3 mt-3">
          <div className="d-flex justify-content-between align-items-center">
            <h5>💆 Manage Wellness Programs</h5>
            <Button variant="primary" onClick={() => handleShow()}>
              + Add Program
            </Button>
          </div>

          {loading ? (
            <div className="text-center p-3">
              <Spinner animation="border" variant="primary" />
            </div>
          ) : (
            <Table striped bordered hover className="mt-3">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Duration (days)</th>
                  <th>Fee (₹)</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {services.length > 0 ? (
                  services.map((s) => (
                    <tr key={s.id}>
                      <td>{s.id}</td>
                      <td>{s.name}</td>
                      <td>{s.description}</td>
                      <td>{s.duration}</td>
                      <td>{s.fee}</td>
                      <td>
                        <Button
                          size="sm"
                          variant="warning"
                          className="me-2"
                          onClick={() => handleShow(s)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          onClick={() => handleDelete(s.id)}
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No wellness services available.
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          )}
        </Card>
      </Col>

      {/* Modal for Add/Edit */}
      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{editId ? "Edit Program" : "Add Program"}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSave}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Duration (days)</Form.Label>
              <Form.Control
                type="number"
                value={form.duration}
                onChange={(e) => setForm({ ...form, duration: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Fee (₹)</Form.Label>
              <Form.Control
                type="number"
                step="0.01"
                value={form.fee}
                onChange={(e) => setForm({ ...form, fee: e.target.value })}
                required
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit" variant="success">
              Save
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </Row>
  );
}

export default AdminDashboard;
