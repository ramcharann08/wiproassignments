import React, { useEffect, useState } from "react";
import API from "../api/axiosConfig";
import { Container, Card, ListGroup, Spinner, Button } from "react-bootstrap";

function WellnessServices() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  const patientId = localStorage.getItem("patientId");
  const token = localStorage.getItem("token");

  useEffect(() => {
    API.get("/services") // ✅ backend: @RequestMapping("/api/services")
      .then((res) => setServices(res.data))
      .catch(() => alert("Error fetching services"))
      .finally(() => setLoading(false));
  }, []);

  // ✅ Enroll patient into a service
  const handleEnroll = async (serviceId, serviceName) => {
    try {
      if (!patientId) {
        alert("⚠️ You must be logged in as a patient to enroll.");
        return;
      }

      await API.post(
        `/enrollments/${serviceId}/patients/${patientId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert(`✅ Successfully enrolled into "${serviceName}"!`);
    } catch (err) {
      console.error("Error enrolling:", err);
      if (err.response && err.response.status === 409) {
        alert("⚠️ You are already enrolled in this service.");
      } else {
        alert("❌ Error enrolling into the program.");
      }
    }
  };

  return (
    <Container className="mt-4">
      <Card className="shadow">
        <Card.Body>
          <h3 className="mb-3">💆 Wellness Services</h3>

          {loading ? (
            <div className="text-center p-3">
              <Spinner animation="border" variant="primary" />
            </div>
          ) : (
            <ListGroup>
              {services.length > 0 ? (
                services.map((s) => (
                  <ListGroup.Item
                    key={s.id}
                    className="d-flex justify-content-between align-items-center"
                  >
                    <div>
                      <strong>{s.name}</strong> — {s.description} <br />
                      ⏳ Duration: {s.duration} days <br />
                      💰 Fee: ₹{s.fee}
                    </div>
                    <Button
                      variant="success"
                      size="sm"
                      onClick={() => handleEnroll(s.id, s.name)}
                    >
                      Enroll
                    </Button>
                  </ListGroup.Item>
                ))
              ) : (
                <ListGroup.Item>No wellness services available.</ListGroup.Item>
              )}
            </ListGroup>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
}

export default WellnessServices;
