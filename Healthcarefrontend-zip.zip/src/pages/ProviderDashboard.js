import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { Row, Col, Card, Table, Button, Spinner } from "react-bootstrap";
import API from "../api/axiosConfig";

function ProviderDashboard() {
  const [provider, setProvider] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  const providerId = localStorage.getItem("providerId");

  const getStatusLabel = (status) => {
    switch (status) {
      case "CONFIRMED":
        return "APPROVED";
      case "CANCELLED":
        return "REJECTED";
      default:
        return status;
    }
  };

  const fetchProvider = async () => {
    const res = await API.get(`/providers/${providerId}`);
    setProvider(res.data);
  };

  const fetchAppointments = async () => {
    const res = await API.get(`/appointments/provider/${providerId}`);
    setAppointments(res.data);
  };

  useEffect(() => {
    if (!providerId) {
      alert("No provider logged in! Please login again.");
      window.location.href = "/login";
      return;
    }
    Promise.all([fetchProvider(), fetchAppointments()]).finally(() =>
      setLoading(false)
    );
  }, [providerId]);

  const updateStatus = async (appointmentId, status) => {
    await API.put(`/appointments/${appointmentId}/status`, { status });
    fetchAppointments();
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <Row>
      <Col md={3}>
        <Sidebar
          links={[
            { label: "My Appointments", path: "/provider" },
            { label: "Patients", path: "/patients" },
          ]}
        />
      </Col>

      <Col md={9} className="p-4">
        <h2>👨‍⚕️ Provider Dashboard</h2>

        {provider && (
          <Card className="shadow p-3 mb-4">
            <h5>👤 Profile Information</h5>
            <p><strong>Name:</strong> {provider.name}</p>
            <p><strong>Email:</strong> {provider.email}</p>
            <p><strong>Specialization:</strong> {provider.specialization}</p>
            <p><strong>Phone:</strong> {provider.phone}</p>
            <p><strong>Role:</strong> {provider.role}</p>
          </Card>
        )}

        <Card className="shadow p-3">
          <h5>📅 My Appointments</h5>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Date & Time</th>
                <th>Notes</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {appointments.length > 0 ? (
                appointments.map((a) => (
                  <tr key={a.id}>
                    <td>{a.id}</td>
                    <td>{a.patient?.name || "N/A"}</td>
                    <td>{a.appointmentDate}</td>
                    <td>{a.notes}</td>
                    <td>{getStatusLabel(a.status)}</td>
                    <td>
                      {a.status === "PENDING" && (
                        <>
                          <Button
                            variant="success"
                            size="sm"
                            className="me-2"
                            onClick={() => updateStatus(a.id, "APPROVED")}
                          >
                            Approve
                          </Button>
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => updateStatus(a.id, "REJECTED")}
                          >
                            Reject
                          </Button>
                        </>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center">No appointments found</td>
                </tr>
              )}
            </tbody>
          </Table>
        </Card>
      </Col>
    </Row>
  );
}

export default ProviderDashboard;
