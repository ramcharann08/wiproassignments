import React, { useEffect, useState } from "react";
import API from "../api/axiosConfig";
import { Card, Row, Col, Table, Button, Form, Spinner } from "react-bootstrap";
import Sidebar from "../components/Sidebar";
import { PieChart, Pie, Cell, Tooltip, Legend } from "recharts";

function PatientDashboard() {
  const [patient, setPatient] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [providers, setProviders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    providerId: "",
    appointmentDate: "",
    notes: "",
  });

  const patientId = localStorage.getItem("patientId");

  const fetchPatient = () =>
    API.get(`/patients/${patientId}`).then((res) => setPatient(res.data));

  const fetchAppointments = () =>
    API.get(`/appointments/patient/${patientId}`).then((res) =>
      setAppointments(res.data)
    );

  const fetchProviders = () =>
    API.get(`/providers`).then((res) => setProviders(res.data));

  useEffect(() => {
    if (!patientId) {
      alert("No patient logged in! Please login again.");
      window.location.href = "/login";
      return;
    }
    Promise.all([fetchPatient(), fetchAppointments(), fetchProviders()]).finally(
      () => setLoading(false)
    );
  }, [patientId]);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleBook = (e) => {
    e.preventDefault();
    const payload = {
      patientId,
      providerId: form.providerId,
      appointmentDate: form.appointmentDate,
      notes: form.notes,
    };
    API.post("/appointments", payload)
      .then(() => {
        alert("Appointment booked!");
        fetchAppointments();
        setForm({ providerId: "", appointmentDate: "", notes: "" });
      })
      .catch(() => alert("Error booking appointment"));
  };

  const data = [
    { name: "Approved", value: appointments.filter((a) => a.status === "CONFIRMED").length },
    { name: "Pending", value: appointments.filter((a) => a.status === "PENDING").length },
    { name: "Rejected", value: appointments.filter((a) => a.status === "CANCELLED").length },
  ];
  const COLORS = ["#28a745", "#ffc107", "#dc3545"];

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <Row>
      <Col md={3}>
        <Sidebar
          links={[
            { label: "My Appointments", path: "/patient" },
            { label: "Wellness Services", path: "/wellness" },
            { label: "Payments", path: "/payments" },
          ]}
        />
      </Col>

      <Col md={9} className="p-4">
        <h2>👤 Patient Dashboard</h2>

        {patient && (
          <Card className="shadow p-3 mb-4">
            <h5>👤 Profile Information</h5>
            <p><strong>Name:</strong> {patient.name}</p>
            <p><strong>Email:</strong> {patient.email}</p>
            <p><strong>Phone:</strong> {patient.phone}</p>
            <p><strong>Address:</strong> {patient.address}</p>
            <p><strong>DOB:</strong> {patient.dob}</p>
            <p><strong>Gender:</strong> {patient.gender}</p>
          </Card>
        )}

        <Card className="shadow p-3 mb-4">
          <h5>📊 Appointment Summary</h5>
          <PieChart width={400} height={300}>
            <Pie data={data} dataKey="value" outerRadius={100} label>
              {data.map((entry, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </Card>

        <Card className="shadow p-3 mb-4">
          <h5>📅 Book Appointment</h5>
          <Form onSubmit={handleBook}>
            <Form.Group className="mb-3">
              <Form.Label>Select Provider</Form.Label>
              <Form.Select
                name="providerId"
                value={form.providerId}
                onChange={handleChange}
                required
              >
                <option value="">-- Select --</option>
                {providers.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.specialization})
                  </option>
                ))}
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Date & Time</Form.Label>
              <Form.Control
                type="datetime-local"
                name="appointmentDate"
                value={form.appointmentDate}
                onChange={handleChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Reason</Form.Label>
              <Form.Control
                type="text"
                name="notes"
                value={form.notes}
                onChange={handleChange}
                required
              />
            </Form.Group>
            <Button type="submit" variant="primary">Book Appointment</Button>
          </Form>
        </Card>

        <Card className="shadow p-3">
          <h5>📋 My Appointments</h5>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Provider</th>
                <th>Date & Time</th>
                <th>Notes</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {appointments.length > 0 ? (
                appointments.map((a) => (
                  <tr key={a.id}>
                    <td>{a.id}</td>
                    <td>{a.provider?.name || "N/A"}</td>
                    <td>{a.appointmentDate}</td>
                    <td>{a.notes}</td>
                    <td>{a.status}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="text-center">No appointments</td>
                </tr>
              )}
            </tbody>
          </Table>
        </Card>
      </Col>
    </Row>
  );
}

export default PatientDashboard;
