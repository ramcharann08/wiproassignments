import React, { useState } from "react";
import API from "../api/axiosConfig";
import { useNavigate } from "react-router-dom";
import { Card, Form, Button, Container, Row, Col } from "react-bootstrap";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/auth/login", { email, password });
      const data = res.data;

      // ✅ Clear old storage before saving
      localStorage.clear();

      // ✅ Save token + role
      if (data.token) {
        localStorage.setItem("token", data.token);
      }
      if (data.role) {
        localStorage.setItem("role", data.role);
      }

      // ✅ Role-based navigation
      switch (data.role) {
        case "PATIENT":
          if (data.patientId) {
            localStorage.setItem("patientId", data.patientId);
            navigate("/patient");
          } else {
            alert("Patient ID missing in response!");
          }
          break;

        case "PROVIDER":
        case "DOCTOR":
        case "WELLNESS_PROVIDER":
          if (data.providerId) {
            localStorage.setItem("providerId", data.providerId);
            navigate("/provider");
          } else {
            alert("Provider ID missing in response!");
          }
          break;

        case "ADMIN":
          if (data.adminId) {
            localStorage.setItem("adminId", data.adminId);
          }
          navigate("/admin"); // ✅ Admin Dashboard
          break;

        default:
          alert("Invalid role or missing data in login response!");
      }
    } catch (err) {
      console.error("Login error:", err);
      alert("Invalid login! Please check your email or password.");
    }
  };

  return (
    <Container
      className="d-flex justify-content-center align-items-center"
      style={{ minHeight: "80vh" }}
    >
      <Row>
        <Col>
          <Card style={{ width: "25rem" }} className="shadow">
            <Card.Body>
              <h3 className="text-center mb-4">🔑 Login</h3>
              <Form onSubmit={handleLogin}>
                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </Form.Group>
                <Button type="submit" className="w-100" variant="primary">
                  Login
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Login;
