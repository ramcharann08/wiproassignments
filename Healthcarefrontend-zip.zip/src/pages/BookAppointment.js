import React, { useState, useEffect } from "react";
import { Card, Form, Button, Spinner } from "react-bootstrap";
import API from "../api/axiosConfig";

function BookAppointment() {
  const [patients, setPatients] = useState([]);
  const [providers, setProviders] = useState([]);
  const [form, setForm] = useState({
    patientId: "",
    providerId: "",
    appointmentDate: "",
    notes: "",
  });
  const [loading, setLoading] = useState(false);

  // ✅ Fetch patients + providers
  useEffect(() => {
    const fetchData = async () => {
      try {
        const resPatients = await API.get("/patients");
        const resProviders = await API.get("/providers");
        setPatients(resPatients.data);
        setProviders(resProviders.data);
      } catch (err) {
        console.error(err);
        alert("Error loading patients/providers");
      }
    };
    fetchData();
  }, []);

  // ✅ Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  // ✅ Submit booking
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.patientId || !form.providerId || !form.appointmentDate) {
      alert("Please fill all required fields");
      return;
    }

    const payload = {
      patientId: form.patientId,
      providerId: form.providerId,
      appointmentDate: form.appointmentDate, // ✅ matches backend
      notes: form.notes,
    };

    setLoading(true);
    try {
      await API.post("/appointments", payload);
      alert("Appointment booked successfully ✅");
      setForm({ patientId: "", providerId: "", appointmentDate: "", notes: "" });
    } catch (err) {
      console.error(err);
      alert("Error booking appointment ❌");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="d-flex justify-content-center mt-4">
      <Card className="p-4 shadow" style={{ width: "500px" }}>
        <h3 className="mb-4 text-center">📅 Book Appointment</h3>
        <Form onSubmit={handleSubmit}>
          {/* Patient */}
          <Form.Group className="mb-3">
            <Form.Label>Patient</Form.Label>
            <Form.Select
              name="patientId"
              value={form.patientId}
              onChange={handleChange}
              required
            >
              <option value="">-- Select Patient --</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.email})
                </option>
              ))}
            </Form.Select>
          </Form.Group>

          {/* Provider */}
          <Form.Group className="mb-3">
            <Form.Label>Provider</Form.Label>
            <Form.Select
              name="providerId"
              value={form.providerId}
              onChange={handleChange}
              required
            >
              <option value="">-- Select Provider --</option>
              {providers.map((pr) => (
                <option key={pr.id} value={pr.id}>
                  {pr.name} - {pr.specialization}
                </option>
              ))}
            </Form.Select>
          </Form.Group>

          {/* Date & Time */}
          <Form.Group className="mb-3">
            <Form.Label>Appointment Date & Time</Form.Label>
            <Form.Control
              type="datetime-local"
              name="appointmentDate" // ✅ fixed key
              value={form.appointmentDate}
              onChange={handleChange}
              required
            />
          </Form.Group>

          {/* Notes */}
          <Form.Group className="mb-3">
            <Form.Label>Notes / Reason</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="notes" // ✅ matches backend
              value={form.notes}
              onChange={handleChange}
              placeholder="Reason for visit"
            />
          </Form.Group>

          <Button
            type="submit"
            variant="primary"
            className="w-100"
            disabled={loading}
          >
            {loading ? (
              <>
                <Spinner
                  as="span"
                  animation="border"
                  size="sm"
                  role="status"
                  aria-hidden="true"
                />{" "}
                Booking...
              </>
            ) : (
              "Book Appointment"
            )}
          </Button>
        </Form>
      </Card>
    </div>
  );
}

export default BookAppointment;
