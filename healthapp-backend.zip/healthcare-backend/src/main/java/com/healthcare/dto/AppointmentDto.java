package com.healthcare.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;

public class AppointmentDto {

    @NotNull(message = "Patient ID is required")
    private Long patientId;

    @NotNull(message = "Provider ID is required")
    private Long providerId;

    @NotBlank(message = "Appointment date is required")
    private String appointmentDate; // Format: yyyy-MM-ddTHH:mm

    private String notes; // Reason or extra info

    private String status; // APPROVED, REJECTED, PENDING, etc.

    public AppointmentDto() {}

    // Getters and Setters
    public Long getPatientId() { return patientId; }
    public void setPatientId(Long patientId) { this.patientId = patientId; }

    public Long getProviderId() { return providerId; }
    public void setProviderId(Long providerId) { this.providerId = providerId; }

    public String getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(String appointmentDate) { this.appointmentDate = appointmentDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getStatus() { return status; }

    // ✅ normalize status (APPROVED/REJECTED → uppercase always)
    public void setStatus(String status) {
        this.status = (status != null ? status.trim().toUpperCase() : null);
    }
}
