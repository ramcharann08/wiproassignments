package com.healthcare.dto;

public class LoginResponse {
    private String token;
    private String role;
    private Long patientId;
    private Long providerId;
    private Long adminId;   // ✅ Added for Admin

    public LoginResponse(String token, String role, Long patientId, Long providerId, Long adminId) {
        this.token = token;
        this.role = role;
        this.patientId = patientId;
        this.providerId = providerId;
        this.adminId = adminId;
    }

    public String getToken() { return token; }
    public String getRole() { return role; }
    public Long getPatientId() { return patientId; }
    public Long getProviderId() { return providerId; }
    public Long getAdminId() { return adminId; }
}
