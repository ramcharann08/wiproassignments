package com.healthcare.repository;

import com.healthcare.entity.Provider;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ProviderRepository extends JpaRepository<Provider, Long> {

    // ✅ find provider by email
    Optional<Provider> findByEmail(String email);

    // ✅ count providers (Admin needs this)
    long count();

    // ✅ if needed: check existence by email
    boolean existsByEmail(String email);
}
