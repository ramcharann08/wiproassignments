package com.healthcare.repository;

import com.healthcare.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Long> {

    // ✅ find patient by email
    Optional<Patient> findByEmail(String email);

    // ✅ count patients (Admin needs this)
    long count();

    // ✅ if needed: check existence by email
    boolean existsByEmail(String email);
}
