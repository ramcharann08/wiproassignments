package com.healthcare.repository;

import com.healthcare.entity.WellnessEnrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface WellnessEnrollmentRepository extends JpaRepository<WellnessEnrollment, Long> {

    // ✅ Patient-specific enrollments
    List<WellnessEnrollment> findByPatientId(Long patientId);

    // ✅ Service-specific enrollments
    List<WellnessEnrollment> findByServiceId(Long serviceId);

    // ✅ Counts (efficient for admin dashboard)
    long countByServiceId(Long serviceId);

    long countByPatientId(Long patientId);
}
