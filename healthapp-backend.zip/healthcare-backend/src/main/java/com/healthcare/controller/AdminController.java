package com.healthcare.controller;

import com.healthcare.entity.Provider;
import com.healthcare.entity.Patient;
import com.healthcare.entity.WellnessService;
import com.healthcare.entity.WellnessEnrollment;
import com.healthcare.service.WellnessServiceService;
import com.healthcare.repository.ProviderRepository;
import com.healthcare.repository.PatientRepository;
import com.healthcare.repository.WellnessEnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private ProviderRepository providerRepo;

    @Autowired
    private PatientRepository patientRepo;

    @Autowired
    private WellnessServiceService wellnessService;

    @Autowired
    private WellnessEnrollmentRepository enrollmentRepo;

    // ✅ Get all providers
    @GetMapping("/providers")
    public List<Provider> getAllProviders() {
        return providerRepo.findAll();
    }

    // ✅ Get all patients
    @GetMapping("/patients")
    public List<Patient> getAllPatients() {
        return patientRepo.findAll();
    }

    // ✅ Count providers
    @GetMapping("/providers/count")
    public ResponseEntity<Long> getProviderCount() {
        return ResponseEntity.ok(providerRepo.count());
    }

    // ✅ Count patients
    @GetMapping("/patients/count")
    public ResponseEntity<Long> getPatientCount() {
        return ResponseEntity.ok(patientRepo.count());
    }

    // ✅ Admin can create a wellness program
    @PostMapping("/wellness")
    public ResponseEntity<WellnessService> createProgram(@RequestBody WellnessService program) {
        return ResponseEntity.ok(wellnessService.createFromEntity(program));
    }

    // ✅ Admin can update a wellness program
    @PutMapping("/wellness/{id}")
    public ResponseEntity<WellnessService> updateProgram(
            @PathVariable Long id,
            @RequestBody WellnessService program) {
        return ResponseEntity.ok(wellnessService.updateFromEntity(id, program));
    }

    // ✅ Get all wellness programs
    @GetMapping("/wellness")
    public List<WellnessService> getPrograms() {
        return wellnessService.all();
    }

    // ✅ Delete wellness program
    @DeleteMapping("/wellness/{id}")
    public ResponseEntity<Void> deleteProgram(@PathVariable Long id) {
        wellnessService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ Get all enrollments (all patients enrolled in all programs)
    @GetMapping("/enrollments")
    public List<WellnessEnrollment> getAllEnrollments() {
        return enrollmentRepo.findAll();
    }

    // ✅ Get enrollments for a specific wellness program
    @GetMapping("/wellness/{id}/enrollments")
    public List<WellnessEnrollment> getProgramEnrollments(@PathVariable Long id) {
        return enrollmentRepo.findByServiceId(id);
    }

    // ✅ Get enrollment counts per wellness program
    @GetMapping("/wellness/enrollments/count")
    public ResponseEntity<Map<String, Long>> getProgramEnrollmentCounts() {
        List<WellnessService> services = wellnessService.all();
        Map<String, Long> counts = new HashMap<>();
        for (WellnessService ws : services) {
            long count = enrollmentRepo.countByServiceId(ws.getId()); // ✅ efficient count
            counts.put(ws.getName(), count);
        }
        return ResponseEntity.ok(counts);
    }

    // ✅ Total enrollments across all programs
    @GetMapping("/enrollments/count")
    public ResponseEntity<Long> getTotalEnrollments() {
        return ResponseEntity.ok(enrollmentRepo.count());
    }

    // ✅ Enrollment count per patient (for admin analytics)
    @GetMapping("/patients/{id}/enrollments/count")
    public ResponseEntity<Long> getPatientEnrollmentCount(@PathVariable Long id) {
        return ResponseEntity.ok(enrollmentRepo.countByPatientId(id));
    }
}
