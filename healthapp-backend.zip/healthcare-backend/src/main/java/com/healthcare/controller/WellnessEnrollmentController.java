package com.healthcare.controller;

import com.healthcare.entity.WellnessEnrollment;
import com.healthcare.service.WellnessEnrollmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "*")
public class WellnessEnrollmentController {

    private final WellnessEnrollmentService enrollmentService;

    public WellnessEnrollmentController(WellnessEnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }

    // ✅ Patient enrolls into a wellness service
    @PostMapping("/{serviceId}/patients/{patientId}")
    public ResponseEntity<String> enroll(
            @PathVariable Long serviceId,
            @PathVariable Long patientId) {

        WellnessEnrollment enrollment = enrollmentService.enroll(patientId, serviceId);

        return ResponseEntity.ok("Enrolled successfully into " +
                enrollment.getService().getName() +
                " on " + enrollment.getEnrolledAt());
    }

    // ✅ Get all enrolled services of a patient
    @GetMapping("/patients/{patientId}")
    public ResponseEntity<List<WellnessEnrollment>> getEnrolledByPatient(@PathVariable Long patientId) {
        return ResponseEntity.ok(enrollmentService.getPatientEnrollments(patientId));
    }

    // ✅ Get all enrollments for a service
    @GetMapping("/services/{serviceId}")
    public ResponseEntity<List<WellnessEnrollment>> getEnrolledByService(@PathVariable Long serviceId) {
        return ResponseEntity.ok(enrollmentService.getServiceEnrollments(serviceId));
    }

    // ✅ Admin: Get all enrollments
    @GetMapping
    public ResponseEntity<List<WellnessEnrollment>> getAllEnrollments() {
        return ResponseEntity.ok(enrollmentService.getAllEnrollments());
    }
}
