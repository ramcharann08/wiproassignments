package com.healthcare.service.impl;

import com.healthcare.entity.Patient;
import com.healthcare.entity.WellnessEnrollment;
import com.healthcare.entity.WellnessService;
import com.healthcare.repository.PatientRepository;
import com.healthcare.repository.WellnessEnrollmentRepository;
import com.healthcare.repository.WellnessServiceRepository;
import com.healthcare.service.WellnessEnrollmentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WellnessEnrollmentServiceImpl implements WellnessEnrollmentService {

    private final WellnessEnrollmentRepository enrollmentRepo;
    private final PatientRepository patientRepo;
    private final WellnessServiceRepository serviceRepo;

    public WellnessEnrollmentServiceImpl(
            WellnessEnrollmentRepository enrollmentRepo,
            PatientRepository patientRepo,
            WellnessServiceRepository serviceRepo) {
        this.enrollmentRepo = enrollmentRepo;
        this.patientRepo = patientRepo;
        this.serviceRepo = serviceRepo;
    }

    @Override
    public WellnessEnrollment enroll(Long patientId, Long serviceId) {
        Patient patient = patientRepo.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        WellnessService ws = serviceRepo.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("Wellness Service not found"));

        WellnessEnrollment enrollment = new WellnessEnrollment(patient, ws);
        return enrollmentRepo.save(enrollment);
    }

    @Override
    public List<WellnessEnrollment> getPatientEnrollments(Long patientId) {
        return enrollmentRepo.findByPatientId(patientId);
    }

    @Override
    public List<WellnessEnrollment> getServiceEnrollments(Long serviceId) {
        return enrollmentRepo.findByServiceId(serviceId);
    }

    @Override
    public List<WellnessEnrollment> getAllEnrollments() {
        return enrollmentRepo.findAll(); // ✅ Admin can see all
    }
}

