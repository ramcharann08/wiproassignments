package com.healthcare.service;

import com.healthcare.dto.WellnessServiceDto;
import com.healthcare.entity.WellnessService;

import java.util.List;

public interface WellnessServiceService {

    // ✅ Fetch all services
    List<WellnessService> all();

    // ✅ Fetch single service
    WellnessService findById(Long id);

    // ✅ Create new service from DTO
    WellnessService create(WellnessServiceDto dto);

    // ✅ Update existing service using DTO
    WellnessService update(Long id, WellnessServiceDto dto);

    // ✅ Delete a service
    void delete(Long id);

    // ✅ Extra: For Admin direct entity usage
    WellnessService createFromEntity(WellnessService entity);

    WellnessService updateFromEntity(Long id, WellnessService entity);
}
