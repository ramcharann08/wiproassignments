package com.healthcare.service.impl;

import com.healthcare.dto.WellnessServiceDto;
import com.healthcare.entity.WellnessService;
import com.healthcare.repository.WellnessServiceRepository;
import com.healthcare.service.WellnessServiceService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WellnessServiceServiceImpl implements WellnessServiceService {

    private final WellnessServiceRepository repo;

    public WellnessServiceServiceImpl(WellnessServiceRepository repo) {
        this.repo = repo;
    }

    // ✅ Fetch all services
    @Override
    public List<WellnessService> all() {
        return repo.findAll();
    }

    // ✅ Fetch service by id
    @Override
    public WellnessService findById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("WellnessService not found with id " + id));
    }

    // ✅ Create service from DTO
    @Override
    public WellnessService create(WellnessServiceDto dto) {
        WellnessService ws = new WellnessService();
        ws.setName(dto.getName());
        ws.setDescription(dto.getDescription());
        ws.setDuration(dto.getDuration());
        ws.setFee(dto.getFee());
        return repo.save(ws);
    }

    // ✅ Update service from DTO
    @Override
    public WellnessService update(Long id, WellnessServiceDto dto) {
        WellnessService ws = findById(id);
        ws.setName(dto.getName());
        ws.setDescription(dto.getDescription());
        ws.setDuration(dto.getDuration());
        ws.setFee(dto.getFee());
        return repo.save(ws);
    }

    // ✅ Delete service
    @Override
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("WellnessService not found with id " + id);
        }
        repo.deleteById(id);
    }

    // ✅ Admin direct create
    @Override
    public WellnessService createFromEntity(WellnessService entity) {
        return repo.save(entity);
    }

    // ✅ Admin direct update
    @Override
    public WellnessService updateFromEntity(Long id, WellnessService entity) {
        WellnessService ws = findById(id);
        ws.setName(entity.getName());
        ws.setDescription(entity.getDescription());
        ws.setDuration(entity.getDuration());
        ws.setFee(entity.getFee());
        return repo.save(ws);
    }
}
