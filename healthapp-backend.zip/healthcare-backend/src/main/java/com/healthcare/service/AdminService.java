package com.healthcare.service;

import com.healthcare.entity.Patient;
import com.healthcare.entity.Provider;
import com.healthcare.entity.WellnessService;

import java.util.List;

public interface AdminService {
    // Providers
    List<Provider> getAllProviders();

    // Patients
    List<Patient> getAllPatients();

    // Wellness
    WellnessService createProgram(WellnessService program);
    List<WellnessService> getAllPrograms();
    void deleteProgram(Long id);
}
