package com.healthcare.service;

import com.healthcare.entity.WellnessEnrollment;
import java.util.List;

public interface WellnessEnrollmentService {
    WellnessEnrollment enroll(Long patientId, Long serviceId);
    List<WellnessEnrollment> getPatientEnrollments(Long patientId);
    List<WellnessEnrollment> getServiceEnrollments(Long serviceId);
    List<WellnessEnrollment> getAllEnrollments(); // ✅ Admin access
}
