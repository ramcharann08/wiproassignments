package com.healthcare.service.impl;

import com.healthcare.entity.Patient;
import com.healthcare.entity.Provider;
import com.healthcare.entity.WellnessService;
import com.healthcare.repository.PatientRepository;
import com.healthcare.repository.ProviderRepository;
import com.healthcare.repository.WellnessServiceRepository;
import com.healthcare.service.AdminService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {

    private final ProviderRepository providerRepo;
    private final PatientRepository patientRepo;
    private final WellnessServiceRepository wellnessRepo;

    public AdminServiceImpl(ProviderRepository providerRepo,
                            PatientRepository patientRepo,
                            WellnessServiceRepository wellnessRepo) {
        this.providerRepo = providerRepo;
        this.patientRepo = patientRepo;
        this.wellnessRepo = wellnessRepo;
    }

    @Override
    public List<Provider> getAllProviders() {
        return providerRepo.findAll();
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepo.findAll();
    }

    @Override
    public WellnessService createProgram(WellnessService program) {
        return wellnessRepo.save(program);
    }

    @Override
    public List<WellnessService> getAllPrograms() {
        return wellnessRepo.findAll();
    }

    @Override
    public void deleteProgram(Long id) {
        wellnessRepo.deleteById(id);
    }
}
